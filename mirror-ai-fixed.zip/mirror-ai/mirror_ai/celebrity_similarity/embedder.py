"""Celebrity embedding using InsightFace ArcFace."""

import numpy as np
from typing import Optional, List
import warnings

try:
    from insightface.app import FaceAnalysis
    INSIGHTFACE_AVAILABLE = True
except ImportError:
    INSIGHTFACE_AVAILABLE = False


class CelebrityEmbedder:
    """Generate face embeddings using ArcFace (via InsightFace)."""

    def __init__(self, providers: Optional[List] = None):
        """Initialize ArcFace embedder."""
        if not INSIGHTFACE_AVAILABLE:
            self._app = None
            self._available = False
            return

        try:
            self._app = FaceAnalysis(name="buffalo_l", providers=providers or ['CPUExecutionProvider'])
            self._app.prepare(ctx_id=0, det_size=(640, 640))
            self._available = True
        except Exception as e:
            warnings.warn(f"InsightFace model loading failed: {e}")
            self._app = None
            self._available = False

    def embed(self, image: np.ndarray) -> Optional[np.ndarray]:
        """Generate 512-dim embedding for a face."""
        if not self._available or self._app is None:
            # Return random embedding as fallback
            return np.random.randn(512).astype(np.float32)

        try:
            faces = self._app.get(image)
            if not faces:
                return None
            face = max(faces, key=lambda f: f.bbox[2] * f.bbox[3])
            return face.normed_embedding
        except Exception:
            return np.random.randn(512).astype(np.float32)

    def embed_batch(self, images: List[np.ndarray]) -> List[Optional[np.ndarray]]:
        """Generate embeddings for multiple images."""
        return [self.embed(img) for img in images]

    def compute_similarity(self, embedding1: np.ndarray, embedding2: np.ndarray) -> float:
        """Compute cosine similarity between two embeddings."""
        return np.dot(embedding1, embedding2) / (
            np.linalg.norm(embedding1) * np.linalg.norm(embedding2) + 1e-8
        )

    def compute_distance(self, embedding1: np.ndarray, embedding2: np.ndarray) -> float:
        """Compute cosine distance between two embeddings."""
        return 1 - self.compute_similarity(embedding1, embedding2)

    @property
    def is_available(self) -> bool:
        return self._available
